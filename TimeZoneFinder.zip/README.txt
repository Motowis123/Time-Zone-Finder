Time-Zone-Finder
Finds your timezone
Install pip if you havent by typing this in your cmd:
python get-pip.py
And intall tzlocal:
pip install tzlocal
Requires Python, install python here: https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe
PASTE LINK IN BROWSER TO GET RIGHT VERSION

 __  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
 |  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
 | |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
 | |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
 |_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 