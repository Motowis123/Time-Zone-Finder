import tkinter as tk
from datetime import datetime
from tzlocal import get_localzone

def show_time():
    local_timezone = get_localzone()
    current_time = datetime.now(local_timezone)
    time_string = current_time.strftime("%Y-%m-%d %H:%M:%S %Z%z")

    root = tk.Tk()
    root.title("Current Time")

    label = tk.Label(root, text=time_string, font=("Helvetica", 16))
    label.pack(pady=20, padx=20)

    def close_window():
        root.destroy()

    root.after(10000, close_window)
    root.mainloop()

show_time()
